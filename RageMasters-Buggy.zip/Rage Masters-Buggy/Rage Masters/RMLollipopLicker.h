//
//  RMLollipopLicker.h
//  Rage Masters
//
//  Created by Canopus on 10/31/12.
//  Copyright (c) 2012 iOS Developer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RMLollipopLicker : UIViewController

@end
