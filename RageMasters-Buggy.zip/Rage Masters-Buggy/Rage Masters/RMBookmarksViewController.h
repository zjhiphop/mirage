//
//  RMBookmarksViewController.h
//  Rage Masters
//
//  Created by Canopus on 10/8/12.
//  Copyright (c) 2012 iOS Developer. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RMBookmarks.h"

@interface RMBookmarksViewController : UITableViewController

@end
